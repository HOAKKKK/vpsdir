const axios = require("axios");
const { JSDOM } = require("jsdom");
const utils = require("../lib/utils");
const scrapeIPRoyalProxies = async () => {
  try {
    console.log(`Fetching from IPRoyal`);
    const startTime = Date.now(); 
    console.log('Starting to scrape proxies from iproyal.com from page 1 until end...');
    let totalProxyCount = 0;
    let validCount = 0;
    let indoCount = 0;
    let currentPage = 1;
    let hasMorePages = true;
    let emptyPagesCount = 0;
    const maxEmptyPages = 3;
    const axiosInstance = utils.createAxiosInstance(axios);
    
    console.log('Fetching proxies page by page starting from page 1...\n');
    
    while (hasMorePages && emptyPagesCount < maxEmptyPages) {
      console.log(`Processing page ${currentPage}...`); 
      try {
        const response = await axiosInstance.get(`https://iproyal.com/free-proxy-list/?page=${currentPage}&entries=100`, {
          timeout: 10000
        });
        if (response.status !== 200) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const html = response.data;
        if (html.includes('no proxies found') || html.includes('no results') || html.includes('not found')) {
          console.log(`\nPage ${currentPage} indicates no proxies available. Stopping.`);
          hasMorePages = false;
          break;
        }
        const dom = new JSDOM(html);
        const document = dom.window.document;
        const proxyContainers = document.querySelectorAll('div[data-astro-cid-gpo2soo6]');
        
        if (proxyContainers.length === 0) {
          console.log(`\nNo proxy containers found on page ${currentPage}.`);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
          currentPage++;
          continue;
        }
        const rows = [];
        
        for (const container of proxyContainers) {
          const gridRows = container.querySelectorAll('div[style*="grid-template-columns"]');
          for (const row of gridRows) {
            const isFontSemibold = row.querySelector('.font-semibold') !== null;
            const hasHeaderText = row.textContent.includes('IP') && 
                                 row.textContent.includes('PORT') && 
                                 row.textContent.includes('Protocol');
            
            if (!isFontSemibold && !hasHeaderText) {
              rows.push(row);
            }
          }
        }
        if (rows.length === 0) {
          console.log(`\nNo proxy rows found on page ${currentPage}.`);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
          currentPage++;
          continue;
        }
        emptyPagesCount = 0;
        const pageProxies = [];
        for (const row of rows) {
          const cells = row.querySelectorAll('div.flex.items-center');
          
          if (cells.length >= 2) {
            const ip = cells[0].textContent.trim();
            const port = cells[1].textContent.trim();
            
            if (ip && port) {
              pageProxies.push(`${ip}:${port}`);
            }
          }
        }
        if (pageProxies.length === 0) {
          console.log(`\nNo valid proxies extracted on page ${currentPage}.`);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
          currentPage++;
          continue;
        }
        const results = await utils.processProxies(pageProxies);
        totalProxyCount += pageProxies.length;
        validCount += results.valid;
        indoCount += results.indo;
        console.log(`Page ${currentPage}: Found ${pageProxies.length} proxies (${results.valid} valid, ${results.indo} Indonesian)`);
        currentPage++;
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        console.error(`\nError processing page ${currentPage}:`, error.message);
        try {
          console.log(`Retrying page ${currentPage}...`);
          await new Promise(resolve => setTimeout(resolve, 2000));
          const response = await axiosInstance.get(`https://iproyal.com/free-proxy-list/?page=${currentPage}&entries=100`, {
            timeout: 15000
          });
          
          if (response.status !== 200) {
            throw new Error(`HTTP error on retry! Status: ${response.status}`);
          }
          emptyPagesCount++;
          currentPage++;
          continue;
        } catch (retryError) {
          console.error(`Retry failed for page ${currentPage}:`, retryError.message);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive error/empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
          currentPage++;
        }
      }
    }
    const timeElapsed = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(
      `✅ IPRoyal: Found ${totalProxyCount} proxies (${validCount} valid, ${indoCount} Indonesian) in ${timeElapsed}s`,
    );
    return { total: totalProxyCount, valid: validCount, indo: indoCount };
  } catch (error) {
    console.error(`❌ Error fetching proxies from IPRoyal:`, error.message);
    return { total: 0, valid: 0, indo: 0 };
  }
};

module.exports = scrapeIPRoyalProxies;