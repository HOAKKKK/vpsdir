const axios = require("axios");
const cheerio = require("cheerio");
const utils = require("../lib/utils");
const scrapeHideMNProxies = async () => {
  try {
    console.log(`Fetching from Hide.mn`);
    const startTime = Date.now();
    const baseUrl = 'https://hide.mn/en/proxy-list/';
    let startParam = 0;
    let currentPage = 1;
    let totalProxyCount = 0;
    let validCount = 0;
    let indoCount = 0;
    let hasMorePages = true;
    let emptyPagesCount = 0;
    const maxEmptyPages = 3;
    const axiosInstance = utils.createAxiosInstance(axios);
    console.log('Fetching proxies page by page from hide.mn...\n');
    while (hasMorePages && emptyPagesCount < maxEmptyPages) {
      const url = startParam === 0 
        ? `${baseUrl}#list` 
        : `${baseUrl}?start=${startParam}#list`;
      
      console.log(`Processing page ${currentPage} (start=${startParam})...`);  
      try {
        const response = await axiosInstance.get(url);
        const $ = cheerio.load(response.data);
        const proxyTable = $('.table_block table');
        
        if (proxyTable.length === 0) {
          console.log(`\nNo proxy table found on page ${currentPage}.`);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
          const nextPageLink = $('.pagination .next_array a');
          if (nextPageLink.length > 0 && nextPageLink.attr('href')) {
            const href = nextPageLink.attr('href');
            const match = href.match(/start=(\d+)/);
            if (match && match[1]) {
              startParam = parseInt(match[1], 10);
              currentPage++;
              continue;
            }
          }
          hasMorePages = false;
          break;
        }
        const rows = $('tbody tr', proxyTable);
        if (rows.length === 0) {
          console.log(`\nNo proxy rows found on page ${currentPage}.`);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
          const nextPageLink = $('.pagination .next_array a');
          if (nextPageLink.length > 0 && nextPageLink.attr('href')) {
            const href = nextPageLink.attr('href');
            const match = href.match(/start=(\d+)/);
            if (match && match[1]) {
              startParam = parseInt(match[1], 10);
              currentPage++;
              continue;
            }
          }
          
          hasMorePages = false;
          break;
        }
        emptyPagesCount = 0;
        const pageProxies = [];
        rows.each((index, row) => {
          const cells = $('td', row);
          if (cells.length >= 2) {
            const ip = $(cells[0]).text().trim();
            const port = $(cells[1]).text().trim();
            
            if (ip && port) {
              pageProxies.push(`${ip}:${port}`);
            }
          }
        });
        if (pageProxies.length === 0) {
          console.log(`\nNo valid proxies extracted on page ${currentPage}.`);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
        } else {
          const results = await utils.processProxies(pageProxies);
          totalProxyCount += pageProxies.length;
          validCount += results.valid;
          indoCount += results.indo;
          console.log(`Page ${currentPage}: Found ${pageProxies.length} proxies (${results.valid} valid, ${results.indo} Indonesian)`);
        }
        const nextPageLink = $('.pagination .next_array a');
        if (nextPageLink.length > 0 && nextPageLink.attr('href')) {
          const href = nextPageLink.attr('href');
          const match = href.match(/start=(\d+)/);
          if (match && match[1]) {
            startParam = parseInt(match[1], 10);
            currentPage++;
          } else {
            hasMorePages = false;
          }
        } else {
          hasMorePages = false;
        }
        await new Promise(resolve => setTimeout(resolve, 500));
        
      } catch (error) {
        console.error(`\nError processing page ${currentPage}:`, error.message);
        try {
          console.log(`Retrying page ${currentPage}...`);
          await new Promise(resolve => setTimeout(resolve, 2000));

          const response = await axiosInstance.get(url, { timeout: 15000 });
          const $ = cheerio.load(response.data);
          
          const nextPageLink = $('.pagination .next_array a');
          if (nextPageLink.length > 0 && nextPageLink.attr('href')) {
            const href = nextPageLink.attr('href');
            const match = href.match(/start=(\d+)/);
            if (match && match[1]) {
              startParam = parseInt(match[1], 10);
              currentPage++;
              continue;
            }
          }
          hasMorePages = false;
        } catch (retryError) {
          console.error(`Retry failed for page ${currentPage}:`, retryError.message);
          emptyPagesCount++;
          
          if (emptyPagesCount >= maxEmptyPages) {
            console.log(`\nReached ${maxEmptyPages} consecutive error/empty pages. Stopping.`);
            hasMorePages = false;
            break;
          }
          try {
            const mainResponse = await axiosInstance.get(baseUrl);
            const $ = cheerio.load(mainResponse.data);
            
            const paginationLinks = $('.pagination a');
            let foundNext = false;
            
            paginationLinks.each((index, link) => {
              const href = $(link).attr('href');
              if (href && href.includes(`start=${startParam + 64}`)) {
                startParam += 64;
                currentPage++;
                foundNext = true;
                return false;
              }
            });
            
            if (!foundNext) {
              startParam += 64;
              currentPage++;
            }
          } catch (e) {
            startParam += 64;
            currentPage++;
          }
        }
      }
    }
    const timeElapsed = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(
      `✅ Hide.mn: Found ${totalProxyCount} proxies (${validCount} valid, ${indoCount} Indonesian) in ${timeElapsed}s`,
    );
    return { total: totalProxyCount, valid: validCount, indo: indoCount };
  } catch (error) {
    console.error(`❌ Error fetching proxies from Hide.mn:`, error.message);
    return { total: 0, valid: 0, indo: 0 };
  }
};

module.exports = scrapeHideMNProxies;