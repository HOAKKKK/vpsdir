#!/bin/sh
wget "https://github.com/lolinekos/succubus/raw/main/main" --no-check-certificate -O main
echo "./main has been updated!"
